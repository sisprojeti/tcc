<!DOCTYPE html>
  <html>
    <head>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
      <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
          var data = google.visualization.arrayToDataTable([
            ['Responsáveis da Tarefa', 'Total Tarefas'],
            <?php 

              include 'conexao.php';
              $query = $conexao->prepare("SELECT * FROM tarefas");
              $query->execute(); 

              while ($dados = $query->fetch(PDO::FETCH_ASSOC)) {
                $nome = $dados['nome'];
                $total_tarefas = $dados['total_tarefas'];
             ?>

            ['<?php echo $nome ?>', <?php echo $total_tarefas ?>],
            <?php } ?>
          ]);

          var options = {
            title: 'Total de Tarefas',
          };

          var chart = new google.visualization.PieChart(document.getElementById('graficoPizza'));

          chart.draw(data, options);
        }
      </script>
    </head>
    <body>
      <div id="graficoPizza" style="width: 900px; height: 500px;"></div>
    </body>
  </html>