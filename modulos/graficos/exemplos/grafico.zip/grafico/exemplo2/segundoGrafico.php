<!DOCTYPE html>
  <html>
    <head>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
      <script type="text/javascript">
        google.charts.load('current', {'packages':['bar']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
          var data = google.visualization.arrayToDataTable([
            ['Responsáveis da Tarefa', 'Tarefas Concluidas', 'Total Tarefas'],
            <?php 

            include 'conexao.php';
            $query = $conexao->prepare("SELECT * FROM tarefas");
            $query->execute(); 

            while ($dados = $query->fetch(PDO::FETCH_ASSOC)) {
              $nome = $dados['nome'];
              $tarefas_concluidas = $dados['tarefas_concluidas'];
              $total_tarefas = $dados['total_tarefas'];

             ?>

            ['<?php echo $nome ?>',  <?php echo $tarefas_concluidas ?>, <?php echo $total_tarefas ?>],
            <?php } ?>
          ]);

          var options = {
            chart: {
              title: 'Quantitativo de tarefas por aluno',
              subtitle: 'Nome dos Responsáveis',
            }
          };

          var chart = new google.charts.Bar(document.getElementById('graficoColuna'));

          chart.draw(data, google.charts.Bar.convertOptions(options));
        }
      </script>
    </head>
    <body>
      <div id="graficoColuna" style="width: 800px; height: 500px;"></div>
    </body>
  </html>