<!DOCTYPE html>
 <html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Aluno Responsável', 'Tarefas Concluidas', 'Todas as Tarefas'],
          <?php 

          include 'conexao.php';
          $query = $conexao->prepare("SELECT * FROM tarefas");
          $query->execute(); 

          while ($dados = $query->fetch(PDO::FETCH_ASSOC)) {
            $nome = $dados['nome'];
            $tarefas_concluidas = $dados['tarefas_concluidas'];
            $total_tarefas = $dados['total_tarefas'];

          ?>
          ['<?php echo $nome ?>',  <?php echo $tarefas_concluidas ?>, <?php echo $total_tarefas ?>],

        <?php } ?>
        ]);

        var options = {
          title: 'Performance de Usuário',
          //curveType: 'function',
          legend: { position: 'right' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('graficoLinha'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="graficoLinha" style="width: 900px; height: 500px"></div>
  </body>
</html>