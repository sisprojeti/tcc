<?php 

//Conexão do Banco de Dados Usando PDO
$username = 'root';
$password = '';
$conexao = new PDO( 'mysql:host=localhost;dbname=grafico', $username, $password );


 ?>